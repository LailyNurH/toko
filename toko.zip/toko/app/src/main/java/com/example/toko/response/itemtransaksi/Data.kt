package com.example.toko.response.itemtransaksi

data class Data(
    val item_transaksi: ItemTransaksi
)
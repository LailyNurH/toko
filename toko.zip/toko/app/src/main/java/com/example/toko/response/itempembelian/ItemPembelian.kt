package com.example.toko.response.itempembelian

data class ItemPembelian(
    val id: String,
    val pembelian_id: String,
    val produk_id: String,
    val qty: String
)